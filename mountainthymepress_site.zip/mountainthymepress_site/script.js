let currentPage = 0;
const pages = document.querySelectorAll('.page');
const prevBtn = document.getElementById('prevBtn');
const nextBtn = document.getElementById('nextBtn');

function showPage(index) {
  pages.forEach(page => page.classList.remove('active'));
  pages[index].classList.add('active');
  currentPage = index;
  prevBtn.disabled = currentPage === 0;
  nextBtn.disabled = currentPage === pages.length - 1;
  nextBtn.textContent = currentPage === 0 ? 'Turn the Page →' : 'Turn the Page →';
}

function nextPage() {
  if (currentPage < pages.length - 1) showPage(currentPage + 1);
}

function prevPage() {
  if (currentPage > 0) showPage(currentPage - 1);
}

document.addEventListener('keydown', event => {
  if (event.key === 'ArrowRight') nextPage();
  if (event.key === 'ArrowLeft') prevPage();
});

showPage(0);
