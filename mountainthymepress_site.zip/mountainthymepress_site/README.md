# Mountainthyme Press Website

A free GitHub Pages website for Mountainthyme Press.

Files included:
- index.html
- style.css
- script.js
- assets folder for future illustrations
